﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using ClassroomBooking.Models;
using ClassroomBooking.Services;
using ClassroomBooking.Configuration;

namespace ClassroomBooking
{
    public partial class MainWindow : Window
    {
        private UserService _userService;
        private RoomService _roomService;
        private BookingService _bookingService;
        private AppSettings _settings;

        public MainWindow()
        {
            InitializeComponent();

            // Загрузка конфигурации
            var configService = new ConfigService();
            _settings = configService.Load();

            // Применение настроек к интерфейсу
            this.Title = _settings.AppTitle;
            StatusTextBlock.Text = _settings.StatusMessage;

            _userService = new UserService();
            _roomService = new RoomService();
            _bookingService = new BookingService();

            LoadUsers();
            LoadRooms();
            RefreshBookings();
        }

        private void LoadUsers()
        {
            var users = _userService.GetAllUsers();
            UserComboBox.ItemsSource = users;
            UserComboBox.DisplayMemberPath = "Name";
            UserComboBox.SelectedValuePath = "Id";
        }

        private void LoadRooms()
        {
            var rooms = _roomService.GetAllRooms();
            RoomComboBox.ItemsSource = rooms;
            RoomComboBox.DisplayMemberPath = "Number";
            RoomComboBox.SelectedValuePath = "Id";
        }

        private void BookButton_Click(object sender, RoutedEventArgs e)
        {
            if (UserComboBox.SelectedItem == null || RoomComboBox.SelectedItem == null)
            {
                MessageBox.Show("Выберите пользователя и аудиторию", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (DatePicker.SelectedDate == null)
            {
                MessageBox.Show("Выберите дату", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!TimeSpan.TryParse(StartTimeBox.Text, out TimeSpan startTime) ||
                !TimeSpan.TryParse(EndTimeBox.Text, out TimeSpan endTime))
            {
                MessageBox.Show("Некорректное время", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (startTime >= endTime)
            {
                MessageBox.Show("Время начала должно быть раньше времени окончания", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // 1. Проверка конфигурации рабочего времени
            if (!TimeSpan.TryParse(_settings.WorkDayStart, out TimeSpan workDayStart) ||
                !TimeSpan.TryParse(_settings.WorkDayEnd, out TimeSpan workDayEnd))
            {
                MessageBox.Show("Ошибка конфигурации рабочего времени", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (startTime < workDayStart || endTime > workDayEnd)
            {
                MessageBox.Show($"Бронирование разрешено только с {workDayStart} до {workDayEnd}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // 2. Проверка минимальной длительности
            if ((endTime - startTime).TotalMinutes < _settings.MinBookingMinutes)
            {
                MessageBox.Show($"Минимальная длительность бронирования: {_settings.MinBookingMinutes} мин.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            int userId = (int)UserComboBox.SelectedValue;
            int roomId = (int)RoomComboBox.SelectedValue;
            DateTime date = DatePicker.SelectedDate.Value;
            var room = _roomService.GetRoomById(roomId);

            // 3. Проверка доступности аудитории через конфигурацию
            if (!room.IsAvailable && !_settings.AllowUnavailableRooms)
            {
                MessageBox.Show("Выбранная аудитория недоступна для бронирования.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            bool success = _bookingService.CreateBooking(userId, roomId, date, startTime, endTime);
            if (success)
            {
                MessageBox.Show("Бронирование создано", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                RefreshBookings();
            }
            else
            {
                MessageBox.Show("Конфликт времени или некорректные данные", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void RefreshBookings()
        {
            var bookings = _bookingService.GetAllBookings();
            var displayList = new List<BookingDisplay>();
            foreach (var booking in bookings)
            {
                var user = _userService.GetUserById(booking.UserId);
                var room = _roomService.GetRoomById(booking.RoomId);
                displayList.Add(new BookingDisplay
                {
                    UserName = user?.Name ?? "Неизвестно",
                    RoomNumber = room?.Number ?? "Неизвестно",
                    Date = booking.Date,
                    TimeRange = $"{booking.StartTime:hh\\:mm} - {booking.EndTime:hh\\:mm}"
                });
            }
            BookingsListView.ItemsSource = displayList;
        }
    }

    public class BookingDisplay
    {
        public string UserName { get; set; }
        public string RoomNumber { get; set; }
        public DateTime Date { get; set; }
        public string TimeRange { get; set; }
    }
}